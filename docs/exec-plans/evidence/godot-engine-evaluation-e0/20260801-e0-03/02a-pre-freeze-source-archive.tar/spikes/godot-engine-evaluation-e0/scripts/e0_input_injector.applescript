on run argv
  if (count of argv) is not 1 then error "expected exact target pid" number 64
  set targetPid to (item 1 of argv) as integer
  tell application "System Events"
    if not (exists first application process whose unix id is targetPid) then error "target pid absent" number 65
    set targetProcess to first application process whose unix id is targetPid
    set frontmost of targetProcess to true
    delay 1.0
    repeat with keyName in {"d", "s", "a", "w"}
      key down keyName
      delay 0.1
      key up keyName
      delay 0.25
    end repeat
  end tell
end run

