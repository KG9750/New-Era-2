#!/usr/bin/env python3
"""Evaluate one E0 raw performance capture using the frozen annex rules."""

from __future__ import annotations

import json
import math
from pathlib import Path
import statistics
import sys


def p95(values: list[float]) -> float:
    ordered = sorted(values)
    return ordered[math.ceil(0.95 * len(ordered)) - 1]


def analyze(source: Path) -> dict:
    raw = json.loads(source.read_text(encoding="utf-8"))
    samples = raw["samples"]
    fixture = raw["fixture"]["fixtureId"]
    elapsed = [float(row["elapsedSeconds"]) for row in samples]
    timestamps = [int(row["monotonicTimestampNs"]) for row in samples]
    frames = [int(row["frameIndex"]) for row in samples]
    process_ms = [float(row["TIME_PROCESS"]) * 1000.0 for row in samples]
    memory = [int(row["MEMORY_STATIC"]) for row in samples]
    nodes = [int(row["OBJECT_NODE_COUNT"]) for row in samples]
    fps_windows = [sum(1 for value in elapsed if second <= value < second + 1.0) for second in range(10)]
    memory_limit = memory[0] + max(8 * 1024 * 1024, int(memory[0] * 0.05))
    thirds = []
    for low, high in ((0.0, 10.0 / 3.0), (10.0 / 3.0, 20.0 / 3.0), (20.0 / 3.0, 10.0)):
        bucket = [memory[index] for index, value in enumerate(elapsed) if low <= value < high]
        thirds.append(statistics.median(bucket))
    memory_trend_fail = thirds[0] < thirds[1] < thirds[2] and thirds[2] - thirds[0] > 8 * 1024 * 1024
    finite = all(math.isfinite(float(value)) for row in samples for value in row.values() if isinstance(value, (int, float)))
    hard_pass = (
        len(samples) >= 120
        and all(right > left for left, right in zip(timestamps, timestamps[1:]))
        and len(frames) == len(set(frames))
        and finite
        and nodes[-1] == nodes[0]
        and memory[-1] <= memory_limit
        and not memory_trend_fail
    )
    if fixture == "nominal":
        long_limit = math.floor(0.01 * len(samples))
        long_count = sum(value > 33.33 for value in process_ms)
        threshold_pass = statistics.median(fps_windows) >= 55 and p95(process_ms) <= 16.67 and long_count <= long_limit
    elif fixture == "stress":
        long_limit = math.floor(0.02 * len(samples))
        long_count = sum(value > 50.0 for value in process_ms)
        threshold_pass = p95(process_ms) <= 33.33 and long_count <= long_limit
    else:
        raise ValueError(f"unexpected fixture: {fixture}")
    return {
        "schemaVersion": "new-era-godot-e0-performance-summary-v2",
        "source": str(source),
        "fixtureId": fixture,
        "sampleCount": len(samples),
        "fpsWindows": fps_windows,
        "medianFps": statistics.median(fps_windows),
        "processP95Ms": p95(process_ms),
        "longFrameCount": long_count,
        "longFrameLimit": long_limit,
        "baselineMemory": memory[0],
        "finalMemory": memory[-1],
        "memoryLimit": memory_limit,
        "memoryThirdMedians": thirds,
        "baselineNodeCount": nodes[0],
        "finalNodeCount": nodes[-1],
        "hardChecksPass": hard_pass,
        "thresholdsPass": threshold_pass,
        "status": "PASS" if hard_pass and threshold_pass else "FAIL",
    }


def main() -> int:
    if len(sys.argv) != 3:
        raise SystemExit("usage: analyze_performance.py INPUT.json OUTPUT.json")
    result = analyze(Path(sys.argv[1]))
    Path(sys.argv[2]).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

