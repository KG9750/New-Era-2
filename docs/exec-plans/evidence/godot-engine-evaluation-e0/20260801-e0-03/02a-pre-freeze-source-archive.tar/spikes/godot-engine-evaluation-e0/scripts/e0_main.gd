extends Node2D

const TILE_SIZE := Vector2i(16, 16)
const ATLAS_SIZE := Vector2i(48, 16)
const SOURCE_ID := 0
const CAMERA_STEP := 64.0
const WARMUP_FRAMES := 120
const SAMPLE_SECONDS := 10.0
const MINIMUM_SAMPLE_FRAMES := 120
const ACTION_DELTAS := {
	"e0_camera_right": Vector2(CAMERA_STEP, 0.0),
	"e0_camera_down": Vector2(0.0, CAMERA_STEP),
	"e0_camera_left": Vector2(-CAMERA_STEP, 0.0),
	"e0_camera_up": Vector2(0.0, -CAMERA_STEP),
}
const EXPECTED_ACTIONS := ["e0_camera_right", "e0_camera_down", "e0_camera_left", "e0_camera_up"]
const EXPECTED_CENTERS := [Vector2.ZERO, Vector2(64, 0), Vector2(64, 64), Vector2(0, 64), Vector2.ZERO]

var fixture_id := "nominal"
var mode := "interactive"
var output_path := ""
var grid := Vector2i(64, 36)
var expected_counts := {"Ground": 2304, "Detail": 576, "Overlay": 144}
var layers: Array[TileMapLayer] = []
var fixture_camera: Camera2D
var fixture_manifest: Dictionary = {}

var warmup_count := 0
var sample_start_ns := 0
var samples: Array[Dictionary] = []
var performance_done := false

var phase3_start_usec := 0
var phase3_stage := 0
var resize_checkpoints: Array[Dictionary] = []
var input_ready_usec := 0
var input_events: Array[Dictionary] = []
var pending_input_rows: Array[Dictionary] = []
var input_sequence := 0
var valid_action_count := 0
var last_input_usec := 0
var input_done := false

var witness_start_usec := 0


func _ready() -> void:
	_parse_args()
	_configure_fixture()
	_build_fixture()
	fixture_manifest = _make_fixture_manifest()
	print("E0_FIXTURE_MANIFEST=" + JSON.stringify(fixture_manifest))
	if not _fixture_matches_contract():
		printerr("E0_FIXTURE_COUNT_MISMATCH")
		get_tree().quit(31)
		return
	match mode:
		"smoke":
			call_deferred("_finish_smoke")
		"phase3":
			phase3_start_usec = Time.get_ticks_usec()
		"witness":
			witness_start_usec = Time.get_ticks_usec()


func _process(_delta: float) -> void:
	_finalize_pending_input_rows()
	if mode == "performance" and not performance_done:
		_sample_performance()
	elif mode == "phase3" and not input_done:
		_process_phase3()
	elif mode == "witness" and Time.get_ticks_usec() - witness_start_usec >= 8000000:
		_write_json({"status": "PASS", "mode": "witness", "fixture": _make_fixture_manifest()})
		get_tree().quit(0)


func _input(event: InputEvent) -> void:
	if mode != "phase3" or input_ready_usec == 0 or not (event is InputEventKey):
		return
	_observe_key_event(event as InputEventKey)


func _parse_args() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--fixture="):
			fixture_id = arg.trim_prefix("--fixture=")
		elif arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--output="):
			output_path = arg.trim_prefix("--output=")


func _configure_fixture() -> void:
	if fixture_id == "stress":
		grid = Vector2i(256, 144)
		expected_counts = {"Ground": 36864, "Detail": 9216, "Overlay": 2304}
	elif fixture_id != "nominal":
		printerr("E0_UNKNOWN_FIXTURE=" + fixture_id)
		get_tree().quit(30)


func _build_fixture() -> void:
	var tile_set := TileSet.new()
	tile_set.tile_size = TILE_SIZE
	var atlas_image := Image.create_empty(ATLAS_SIZE.x, ATLAS_SIZE.y, false, Image.FORMAT_RGBA8)
	var colors := [Color("566b4f"), Color("9a8f62"), Color("5f718c")]
	for tile_x in range(3):
		for pixel_y in range(TILE_SIZE.y):
			for pixel_x in range(TILE_SIZE.x):
				atlas_image.set_pixel(tile_x * TILE_SIZE.x + pixel_x, pixel_y, colors[tile_x])
	var atlas_source := TileSetAtlasSource.new()
	atlas_source.texture = ImageTexture.create_from_image(atlas_image)
	atlas_source.texture_region_size = TILE_SIZE
	for tile_x in range(3):
		atlas_source.create_tile(Vector2i(tile_x, 0))
	tile_set.add_source(atlas_source, SOURCE_ID)

	for layer_name in ["Ground", "Detail", "Overlay"]:
		var layer := TileMapLayer.new()
		layer.name = layer_name
		layer.tile_set = tile_set
		layer.position = Vector2(-grid.x * TILE_SIZE.x / 2.0, -grid.y * TILE_SIZE.y / 2.0)
		add_child(layer)
		layers.append(layer)

	for y in range(grid.y):
		for x in range(grid.x):
			var cell := Vector2i(x, y)
			layers[0].set_cell(cell, SOURCE_ID, Vector2i(0, 0), 0)
			if (x + 2 * y) % 4 == 0:
				layers[1].set_cell(cell, SOURCE_ID, Vector2i(1, 0), 0)
			if (3 * x + y) % 16 == 0:
				layers[2].set_cell(cell, SOURCE_ID, Vector2i(2, 0), 0)

	fixture_camera = Camera2D.new()
	fixture_camera.name = "E0Camera"
	fixture_camera.position = Vector2.ZERO
	fixture_camera.position_smoothing_enabled = false
	fixture_camera.drag_horizontal_enabled = false
	fixture_camera.drag_vertical_enabled = false
	add_child(fixture_camera)
	fixture_camera.make_current()
	fixture_camera.force_update_scroll()


func _make_fixture_manifest() -> Dictionary:
	var layer_rows: Array[Dictionary] = []
	var total := 0
	for layer in layers:
		var count := layer.get_used_cells().size()
		var used := layer.get_used_rect()
		total += count
		layer_rows.append({
			"name": String(layer.name),
			"cellCount": count,
			"usedRect": [used.position.x, used.position.y, used.size.x, used.size.y],
		})
	return {
		"fixtureId": fixture_id,
		"grid": [grid.x, grid.y],
		"layers": layer_rows,
		"totalCellCount": total,
		"cameraCurrent": fixture_camera.is_current(),
		"cameraCenter": _vector_to_array(fixture_camera.get_screen_center_position()),
		"displayServer": DisplayServer.get_name(),
		"windowSize": [get_window().size.x, get_window().size.y],
		"visibleRect": _rect_to_array(get_viewport().get_visible_rect()),
	}


func _fixture_matches_contract() -> bool:
	if fixture_manifest["grid"] != [grid.x, grid.y]:
		return false
	var total_expected := 0
	for row in fixture_manifest["layers"]:
		var layer_name: String = row["name"]
		if not expected_counts.has(layer_name) or row["cellCount"] != expected_counts[layer_name]:
			return false
		total_expected += expected_counts[layer_name]
	return fixture_manifest["totalCellCount"] == total_expected


func get_fixture_manifest() -> Dictionary:
	return fixture_manifest.duplicate(true)


func _finish_smoke() -> void:
	await get_tree().process_frame
	_write_json({"status": "PASS", "mode": "smoke", "fixture": _make_fixture_manifest()})
	get_tree().quit(0)


func _process_phase3() -> void:
	var elapsed := float(Time.get_ticks_usec() - phase3_start_usec) / 1000000.0
	if phase3_stage == 0 and elapsed >= 1.0:
		_record_resize_checkpoint("INITIAL_960x540")
		phase3_stage = 1
	elif phase3_stage == 1 and elapsed >= 5.0:
		DisplayServer.window_set_size(Vector2i(1280, 720))
		phase3_stage = 2
	elif phase3_stage == 2 and elapsed >= 6.0:
		_record_resize_checkpoint("RESIZED_1280x720")
		phase3_stage = 3
	elif phase3_stage == 3 and elapsed >= 10.0:
		DisplayServer.window_set_size(Vector2i(960, 540))
		phase3_stage = 4
	elif phase3_stage == 4 and elapsed >= 11.0:
		_record_resize_checkpoint("RESTORED_960x540")
		phase3_stage = 5
	elif phase3_stage == 5 and elapsed >= 15.0:
		input_ready_usec = Time.get_ticks_usec()
		last_input_usec = input_ready_usec
		print("E0_INPUT_READY")
		phase3_stage = 6
	elif phase3_stage == 6:
		_poll_input_completion()


func _record_resize_checkpoint(label: String) -> void:
	fixture_camera.force_update_scroll()
	var row := {
		"label": label,
		"windowSize": [get_window().size.x, get_window().size.y],
		"visibleRect": _rect_to_array(get_viewport().get_visible_rect()),
		"cameraCenter": _vector_to_array(fixture_camera.get_screen_center_position()),
	}
	resize_checkpoints.append(row)
	print("E0_RESIZE_CHECKPOINT=" + JSON.stringify(row))


func _observe_key_event(event: InputEventKey) -> void:
	input_sequence += 1
	last_input_usec = Time.get_ticks_usec()
	var action := _resolve_action(event)
	var before := fixture_camera.get_screen_center_position()
	if event.pressed and not event.echo and action != "":
		fixture_camera.position += ACTION_DELTAS[action]
		valid_action_count += 1
		fixture_camera.force_update_scroll()
	pending_input_rows.append({
		"sequence": input_sequence,
		"pressed": event.pressed,
		"echo": event.echo,
		"keycode": int(event.keycode),
		"physicalKeycode": int(event.physical_keycode),
		"resolvedAction": action,
		"beforeCenter": _vector_to_array(before),
		"afterCenter": [],
	})


func _finalize_pending_input_rows() -> void:
	while not pending_input_rows.is_empty():
		var row: Dictionary = pending_input_rows.pop_front()
		row["afterCenter"] = _vector_to_array(fixture_camera.get_screen_center_position())
		input_events.append(row)
		print("E0_INPUT_EVENT=" + JSON.stringify(row))


func _resolve_action(event: InputEventKey) -> String:
	for action in ACTION_DELTAS.keys():
		if event.is_action(action):
			return action
	return ""


func _poll_input_completion() -> void:
	var now := Time.get_ticks_usec()
	if valid_action_count >= 4 and input_events.size() >= 8 and now - last_input_usec >= 500000:
		input_done = true
		var trace_pass := _input_trace_passes()
		_write_json({
			"status": "PASS" if trace_pass else "FAIL",
			"inputProvenance": "OS_INJECTED_INPUT",
			"fixture": _make_fixture_manifest(),
			"resizeCheckpoints": resize_checkpoints,
			"validActionCount": valid_action_count,
			"events": input_events,
		})
		get_tree().quit(0 if trace_pass else 5)
	elif now - input_ready_usec > 10000000:
		input_done = true
		_write_json({
			"status": "INPUT_DELIVERY_TIMEOUT",
			"inputProvenance": "OS_INJECTED_INPUT",
			"resizeCheckpoints": resize_checkpoints,
			"validActionCount": valid_action_count,
			"events": input_events,
		})
		get_tree().quit(3)


func _input_trace_passes() -> bool:
	if resize_checkpoints.size() != 3 or valid_action_count != 4:
		return false
	var valid_rows: Array[Dictionary] = []
	for row in input_events:
		if row["pressed"] and not row["echo"] and row["resolvedAction"] != "":
			valid_rows.append(row)
		elif row["beforeCenter"] != row["afterCenter"]:
			return false
	if valid_rows.size() != 4:
		return false
	for index in range(4):
		if valid_rows[index]["resolvedAction"] != EXPECTED_ACTIONS[index]:
			return false
		if valid_rows[index]["beforeCenter"] != _vector_to_array(EXPECTED_CENTERS[index]):
			return false
		if valid_rows[index]["afterCenter"] != _vector_to_array(EXPECTED_CENTERS[index + 1]):
			return false
	return fixture_camera.get_screen_center_position().is_equal_approx(Vector2.ZERO)


func _sample_performance() -> void:
	if warmup_count < WARMUP_FRAMES:
		warmup_count += 1
		return
	var now_ns := Time.get_ticks_usec() * 1000
	if sample_start_ns == 0:
		sample_start_ns = now_ns
	var elapsed := float(now_ns - sample_start_ns) / 1000000000.0
	if elapsed < SAMPLE_SECONDS:
		samples.append({
			"frameIndex": Engine.get_process_frames(),
			"monotonicTimestampNs": now_ns,
			"elapsedSeconds": elapsed,
			"TIME_FPS": Performance.get_monitor(Performance.TIME_FPS),
			"TIME_PROCESS": Performance.get_monitor(Performance.TIME_PROCESS),
			"TIME_PHYSICS_PROCESS": Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS),
			"MEMORY_STATIC": Performance.get_monitor(Performance.MEMORY_STATIC),
			"OBJECT_NODE_COUNT": Performance.get_monitor(Performance.OBJECT_NODE_COUNT),
			"RENDER_TOTAL_OBJECTS_IN_FRAME": Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME),
			"RENDER_TOTAL_DRAW_CALLS_IN_FRAME": Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),
			"RENDER_VIDEO_MEM_USED": Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED),
		})
	else:
		performance_done = true
		var enough := samples.size() >= MINIMUM_SAMPLE_FRAMES
		_write_json({
			"status": "CAPTURED" if enough else "INSUFFICIENT_SAMPLES",
			"fixture": _make_fixture_manifest(),
			"warmupFrames": warmup_count,
			"timedSampleSeconds": SAMPLE_SECONDS,
			"minimumSampleFrames": MINIMUM_SAMPLE_FRAMES,
			"sampleCount": samples.size(),
			"samples": samples,
		})
		get_tree().quit(0 if enough else 4)


func _write_json(value: Variant) -> void:
	if output_path == "":
		printerr("E0_OUTPUT_PATH_UNSET")
		return
	var file := FileAccess.open(output_path, FileAccess.WRITE)
	if file == null:
		printerr("E0_OUTPUT_OPEN_FAILED=" + output_path)
		return
	file.store_string(JSON.stringify(value, "\t") + "\n")
	file.close()


func _rect_to_array(rect: Rect2) -> Array:
	return [rect.position.x, rect.position.y, rect.size.x, rect.size.y]


func _vector_to_array(value: Vector2) -> Array:
	return [value.x, value.y]

